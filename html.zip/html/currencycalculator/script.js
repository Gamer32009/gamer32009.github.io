function calc(){
    let EUR = document.getElementById("EUR").value;
    let USD = EUR * 1.06;
    document.getElementById("USD").value = USD
}